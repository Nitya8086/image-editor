import { useState } from 'react';
import { fetchImages } from '../services/api';
import ImageCard from '../components/ImageCard';
import { useNavigate } from 'react-router-dom';

const SearchPage = () => {
    const [query, setQuery] = useState('');
    const [images, setImages] = useState([]);
    const navigate = useNavigate();
console.log("in search page");

    const handleSearch = async () => {
        if (query) {
            const results = await fetchImages(query);
            setImages(results);
        }
    };

    return (
        <div>
            <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Enter search term" />
            <button onClick={handleSearch}>Search</button>
            <div className="grid">
                {images.map((img) => (
                    <ImageCard key={img.id} image={img} onEdit={() => navigate(`/edit/${img.id}`, { state: { imageUrl: img.src.large } })} />
                ))}
            </div>
        </div>
    );
};

export default SearchPage;
