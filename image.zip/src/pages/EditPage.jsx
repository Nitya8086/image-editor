import { useEffect, useRef, useState } from 'react';
import { fabric } from 'fabric';
import { useLocation } from 'react-router-dom';

const EditPage = () => {
    const canvasRef = useRef(null);
    const [canvas, setCanvas] = useState(null);
    const location = useLocation();
    const imageUrl = location.state?.imageUrl;

    useEffect(() => {
        if (!canvas) {
            const fabricCanvas = new fabric.Canvas(canvasRef.current);
            fabric.Image.fromURL(imageUrl, (img) => {
                img.scaleToWidth(500);
                fabricCanvas.add(img);
            });
            setCanvas(fabricCanvas);
        }
    }, [canvas, imageUrl]);

    const addText = () => {
        const text = new fabric.Text('Caption Here', { left: 50, top: 50, fontSize: 20 });
        canvas.add(text);
    };

    const addShape = (shape) => {
        let newShape;
        switch (shape) {
            case 'circle': newShape = new fabric.Circle({ radius: 30, fill: 'red', left: 100, top: 100 }); break;
            case 'rectangle': newShape = new fabric.Rect({ width: 100, height: 50, fill: 'blue', left: 150, top: 150 }); break;
            case 'triangle': newShape = new fabric.Triangle({ width: 60, height: 60, fill: 'green', left: 200, top: 200 }); break;
            default: return;
        }
        canvas.add(newShape);
    };

    const downloadImage = () => {
        const link = document.createElement('a');
        link.href = canvas.toDataURL({ format: 'png' });
        link.download = 'edited-image.png';
        link.click();
    };

    return (
        <div>
            <canvas ref={canvasRef} width={600} height={400}></canvas>
            <button onClick={addText}>Add Text</button>
            <button onClick={() => addShape('circle')}>Add Circle</button>
            <button onClick={() => addShape('rectangle')}>Add Rectangle</button>
            <button onClick={() => addShape('triangle')}>Add Triangle</button>
            <button onClick={downloadImage}>Download</button>
        </div>
    );
};

export default EditPage;
